import{d3 as r}from"./card-09c4bade.js";function o(o){const s=r(o);return s.setHours(23,59,59,999),s}export{o as e};
